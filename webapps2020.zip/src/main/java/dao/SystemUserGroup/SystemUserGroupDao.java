package dao.SystemUserGroup;

import dao.DAO;
import entity.SystemUserGroup;

public interface SystemUserGroupDao extends DAO<SystemUserGroup, Long> {
}
